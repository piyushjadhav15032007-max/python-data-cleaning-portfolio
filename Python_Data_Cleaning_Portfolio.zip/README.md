# Python Data Cleaning Portfolio

## Project Overview
A beginner portfolio project demonstrating basic data
cleaning and exploratory data analysis using Python.

## Objective
Inspect a small practice business dataset, remove
duplicate records, review missing values, identify
potential outliers, and create charts.

## Tools Used
- Python
- Pandas
- Matplotlib
- Google Colab

## Work Completed
1. Inspected the original dataset.
2. Identified and removed duplicate rows.
3. Reviewed missing City and Sales values.
4. Created a data quality report.
5. Used the IQR method to flag potential outliers.
6. Created sales distribution and city sales charts.
7. Exported CSV reports and a project summary.

## Deliverables
- cleaned_customers.csv
- data_quality_report.csv
- potential_outliers.csv
- project_summary.txt

## Data and Limitations
The dataset is a small, manually created practice
dataset. It does not contain real client information.
The results are for demonstration and learning only.
Potential outliers require review; they are not
automatically assumed to be errors.
Missing Sales values were not guessed or invented.

## Author
Beginner Python Data Cleaning Portfolio Project
